#!/bin/bash

SOURCE="/home/abantika/Documents"
BACKUP="/home/abantika/disk_backup"
LOG="/home/abantika/disk_monitor.log"
DAYS=7
THRESHOLD=8

usage=$(df / | awk 'NR==2 {print $5}' | sed 's/%//')

echo "$(date): Disk = $usage%" >> $LOG

if [ "$usage" -gt "$THRESHOLD" ]; then
    echo "Cleaning old files..." >> $LOG
    
    find "$SOURCE" -type f -mtime +$DAYS -print -delete >> $LOG
    
    rsync -av --delete "$SOURCE"/ "$BACKUP"/ >> $LOG
    
    notify-send "Disk Cleanup Done" "Old files deleted & backup updated!"
fi

